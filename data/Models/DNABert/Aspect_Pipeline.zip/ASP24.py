#########################################
### Importing the necessary libraries ###
#########################################

import torch
from torch.utils.data import DataLoader
from transformers import TrainingArguments, Trainer, EarlyStoppingCallback, AutoTokenizer, AutoModelForSequenceClassification
from sklearn.model_selection import StratifiedKFold, train_test_split
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score, confusion_matrix, ConfusionMatrixDisplay
from utils.model_utils import load_model
from utils.data_utils import return_kmer, HF_dataset
from utils.viz_utils import count_plot
from pathlib import Path
from optuna.pruners import MedianPruner
import numpy as np
import pandas as pd
import wandb
import matplotlib.pyplot as plt
import os
import optuna
import joblib
from sklearn.metrics import precision_recall_fscore_support

#############################################
## Initializing variables and reading data ##
#############################################

# Set random seeds for reproducibility
torch.manual_seed(42)
np.random.seed(42)

# Define constants
KMER = 6
NUM_FOLDS = 10  # Number of folds for stratified k-fold cross-validation
RANDOM_SEED = 42  # Random seed for reproducibility
SEQ_MAX_LEN = 512  # max len of BERT
EPOCHS = 15
BATCH_SIZE = 32
TRIALS = 20     #Number of trials for optuna testing hyperparameter search

# Initialize wandb
wandb.init(entity='mtamargo', project="ASPECT2024", name=f"DNABERT_{KMER}_Optuna")
wandb_config = {
    "model_path": f"ASPECT_{KMER}",
    "num_folds": NUM_FOLDS,
    "epochs": EPOCHS,
    "batch_size": BATCH_SIZE,
}
wandb.config.update(wandb_config)

# Define directories and parameters
results_dir = Path("./results") / "ASP" / f"ASP_RUN-Optuna"
results_dir.mkdir(parents=True, exist_ok=True)

f1_flog, acc_flog = {}, {}
sum_acc, sum_f1, eval_results = [], [], []

# Load and preprocess data
tr_set = pd.read_csv("../../datasets/sahil/4000_Cassette_Const_data.csv")
train_set, test_set = train_test_split(
    tr_set,
    test_size=0.99,  # Adjust as needed
    stratify=tr_set["CLASS"],
    random_state=RANDOM_SEED
)

ds_kmer, ds_labels = [], []
for seq, label in zip(train_set["SEQ"], train_set["CLASS"]):
    kmer_seq = return_kmer(seq, K=KMER)
    ds_kmer.append(kmer_seq)
    ds_labels.append(label - 1)

df_kmers = np.array(ds_kmer)
df_labels = np.array(ds_labels)
NUM_CLASSES = len(np.unique(ds_labels))

model_config = {
    "model_path": f"zhihan1996/DNA_bert_{KMER}",
    "num_classes": NUM_CLASSES,
}

# Initialize tokenizer outside the loop if it doesn't change
tokenizer = AutoTokenizer.from_pretrained(model_config["model_path"])

# Define compute_metrics function
def compute_metrics(eval_pred):
    """
    Computes metrics for evaluation.
    """
    logits, labels = eval_pred
    predictions = np.argmax(logits, axis=-1)

    precision, recall, f1, _ = precision_recall_fscore_support(
        labels, predictions, average="weighted"
    )
    acc = accuracy_score(labels, predictions)

    metrics = {"accuracy": acc, "precision": precision, "recall": recall, "f1": f1}
    return metrics

# Define function to plot confusion matrix
def plot_confusion_matrix(trainer, eval_dataset, fold, results_dir):
    predictions, labels, _ = trainer.predict(eval_dataset)
    preds = np.argmax(predictions, axis=-1)
    cm = confusion_matrix(labels, preds)
    disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=["Constitutive", "Cassette"])
    disp.plot(cmap=plt.cm.Blues)
    plt.title(f"Confusion Matrix Fold {fold}")
    plt.savefig(results_dir / f"confusion_matrix_fold_{fold}.png")
    plt.close()

#######################################
### Define the Objective Function for Optuna ###
#######################################

def objective(trial):
    """
    Objective function for Optuna hyperparameter optimization.
    """
    # Sample hyperparameters using the updated methods
    learning_rate = trial.suggest_float('learning_rate', 1e-5, 1e-3, log=True)
    assert learning_rate > 0, "Learning rate must be greater than zero."
    weight_decay = trial.suggest_float('weight_decay', 1e-5, 1e-2, log=True)
    num_train_epochs = trial.suggest_int('num_train_epochs', 5, 15)
    per_device_train_batch_size = trial.suggest_categorical('per_device_train_batch_size', [16, 32, 64])
    gradient_checkpointing = trial.suggest_categorical('gradient_checkpointing', [True, False])

    # Initialize metrics for this trial
    trial_fold_acc = []
    trial_fold_f1 = []

    # Initialize StratifiedKFold inside the objective to ensure independence per trial
    skf = StratifiedKFold(n_splits=NUM_FOLDS, shuffle=True, random_state=RANDOM_SEED)

    for fold, (train_idx, eval_idx) in enumerate(skf.split(df_kmers, df_labels), 1):
        print(f"\n=== Trial {trial.number} - Fold {fold} ===")

        # Split data
        train_kmers, eval_kmers = df_kmers[train_idx], df_kmers[eval_idx]
        train_labels, eval_labels = df_labels[train_idx], df_labels[eval_idx]

        # Plot training class distribution (optional)
        count_plot(train_labels, f"Training Class Distribution Trial {trial.number} Fold {fold}", results_dir)

        # Convert to lists to ensure compatibility
        train_kmers = train_kmers.tolist() if isinstance(train_kmers, np.ndarray) else train_kmers
        eval_kmers = eval_kmers.tolist() if isinstance(eval_kmers, np.ndarray) else eval_kmers
        train_labels = train_labels.tolist()
        eval_labels = eval_labels.tolist()

        # Tokenize data
        train_encodings = tokenizer.batch_encode_plus(
            train_kmers,
            max_length=SEQ_MAX_LEN,
            truncation=True,
            padding=True,
            return_attention_mask=True,
            return_tensors="pt",
        )

        eval_encodings = tokenizer.batch_encode_plus(
            eval_kmers,
            max_length=SEQ_MAX_LEN,
            truncation=True,
            padding=True,
            return_attention_mask=True,
            return_tensors="pt",
        )

        # Create datasets
        train_dataset = HF_dataset(
            train_encodings["input_ids"],
            train_encodings["attention_mask"],
            train_labels
        )
        eval_dataset = HF_dataset(
            eval_encodings["input_ids"],
            eval_encodings["attention_mask"],
            eval_labels
        )

        # Initialize a fresh model for each fold
        model = AutoModelForSequenceClassification.from_pretrained(
            model_config["model_path"], 
            num_labels=NUM_CLASSES
        )

        # Define training arguments with sampled hyperparameters
        training_args = TrainingArguments(
            output_dir=results_dir / f"trial_{trial.number}_fold_{fold}",
            num_train_epochs=num_train_epochs,
            per_device_train_batch_size=per_device_train_batch_size,
            per_device_eval_batch_size=BATCH_SIZE,
            warmup_steps=500,
            weight_decay=weight_decay,
            learning_rate=learning_rate,
            logging_dir=results_dir / f"trial_{trial.number}_fold_{fold}" / "logs",
            logging_steps=60,
            load_best_model_at_end=True,
            evaluation_strategy="epoch",
            save_strategy="epoch",
            fp16=True,
            gradient_checkpointing=gradient_checkpointing,
            metric_for_best_model="eval_f1",
            greater_is_better=True,
            save_total_limit=2,  # Keep only the best models
        )

        # Initialize Trainer with Early Stopping
        trainer = Trainer(
            model=model,
            args=training_args,
            train_dataset=train_dataset,
            eval_dataset=eval_dataset,
            compute_metrics=compute_metrics,
            tokenizer=tokenizer,
            callbacks=[EarlyStoppingCallback(early_stopping_patience=3)]
        )

        # Train the model
        trainer.train()

        # Evaluate the model
        res = trainer.evaluate(eval_dataset)

        # Log metrics to W&B (optional)
        wandb.log({
            f"Trial {trial.number} Fold {fold} Acc": res["eval_accuracy"],
            f"Trial {trial.number} Fold {fold} F1": res["eval_f1"],
            f"Trial {trial.number} Fold {fold} Precision": res["eval_precision"],
            f"Trial {trial.number} Fold {fold} Recall": res["eval_recall"]
        })

        # Collect metrics
        trial_fold_acc.append(res["eval_accuracy"])
        trial_fold_f1.append(res["eval_f1"])

        # Save the trained model for this fold (optional)
        model_path = results_dir / f"trial_{trial.number}_fold_{fold}_model"
        model.save_pretrained(model_path)
        tokenizer.save_pretrained(model_path)
        print(f"Model saved at {model_path}")

        # Plot evaluation class distribution (optional)
        count_plot(eval_labels, f"Evaluation Class Distribution Trial {trial.number} Fold {fold}", results_dir)

        # Plot confusion matrix (optional)
        plot_confusion_matrix(trainer, eval_dataset, fold, results_dir)

    # Calculate average F1 score across all folds for this trial
    avg_f1 = np.mean(trial_fold_f1)
    avg_acc = np.mean(trial_fold_acc)

    print(f"=== Trial {trial.number} Completed ===")
    print(f"Average Accuracy: {avg_acc:.4f}")
    print(f"Average F1 Score: {avg_f1:.4f}")

    # Log average metrics to W&B
    wandb.log({
        f"Trial {trial.number} Average Acc": avg_acc,
        f"Trial {trial.number} Average F1": avg_f1
    })

    return avg_f1  # Optuna will maximize this value

####################################
### Run the Optuna Hyperparameter Optimization ###
####################################

# Create an Optuna study
study = optuna.create_study(direction="maximize", study_name="DNABERT_Hyperparameter_Optimization", pruner=MedianPruner())
study.optimize(objective, n_trials=TRIALS, timeout=None)  # Adjust n_trials as needed: Removed n_jobs=4 because of deadlocks

# Print the best hyperparameters
print("Best hyperparameters:", study.best_params)

# Optionally, save the study for later analysis
joblib.dump(study, 'optuna_study.pkl')

# Finish the W&B run
wandb.finish()
